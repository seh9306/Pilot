#include <iostream>

void error_handle(char *msg) {
	std::cout << msg << std::endl;
}