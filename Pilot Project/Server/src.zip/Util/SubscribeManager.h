#ifndef SUBSCRIBEMANAGER_H
#define SUBSCRIBEMANAGER_H

#include <WinSock2.h>
#include <unordered_map>
#include <list>
#include <string>

class SubscribeManager
{
private:
	static SubscribeManager *sm;
	std::unordered_map<std::string, std::list<SOCKET> *> sockets;
	SubscribeManager();
public:
	~SubscribeManager();
	static SubscribeManager& GetInstance();
	bool Subscribe(char *dir, SOCKET sock);
	bool UnSubscribe(char *dir);
	std::list<SOCKET> *GetSocketsByDir(char *dir);
};

#endif
