#include "PublishProcessor.h"


PublishProcessor::PublishProcessor()
{
}

PublishProcessor::~PublishProcessor()
{
}
