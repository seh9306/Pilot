#include "MoveProcessor.h"



MoveProcessor::MoveProcessor()
{
}


MoveProcessor::~MoveProcessor()
{
}

void MoveProcessor::PacketProcess(SOCKET sock, char * msg)
{

}