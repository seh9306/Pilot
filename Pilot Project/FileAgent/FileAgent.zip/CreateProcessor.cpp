#include "stdafx.h"

#include "CreateProcessor.h"



CreateProcessor::CreateProcessor()
{
}


CreateProcessor::~CreateProcessor()
{
}

void CreateProcessor::PacketProcess(SOCKET sock, char * msg)
{

}